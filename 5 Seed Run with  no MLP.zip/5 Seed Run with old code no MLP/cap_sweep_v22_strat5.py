#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Cap Sweep (Option C) — 5 Seeds, STRATIFIED + DETERMINISTIC PROBE (Paper-Ready)
=============================================================================

What this fixes vs the earlier cap sweep:
  ✅ Stratified sampling for source/train/test sets (balanced per class)
  ✅ Removes tiny-val early stopping (variance amplifier)
  ✅ Uses deterministic full-batch L2-regularized logistic regression via LBFGS

This is designed to make the "none" baseline variance small and make the
spectral-vs-random comparisons interpretable at Nt=100.

Default hard pair:
  vehicles_all -> animals_all  (target is 6-way)

Outputs:
  - outputs_review/cap_sweep_results_per_seed.csv
  - outputs_review/cap_sweep_results_mean_std.csv
  - outputs_review/cap_sweep_plot_mean_std.png

Recommended run (5 seeds):
  python3 cap_sweep_v22_strat5.py \
    --v22_csv scaling_results_multibackbone_v22.csv \
    --src vehicles_all --tgt animals_all \
    --Ns 2000 --Nt 100 --Ntest 2000 \
    --caps 32,64,99,kstar \
    --seeds 20260119,20260218,20260301,20260315,20260329

Author: Vincent Marquez
Date: Jan 2026
"""

import os
import csv
import argparse
import hashlib
import warnings
from collections import defaultdict
from typing import Dict, Tuple, List

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

import torchvision.models as models
import torchvision.transforms as transforms
import torchvision.datasets as datasets
from torch.utils.data import DataLoader, Subset

# Optional plotting
try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    PLOT = True
except Exception:
    plt = None
    PLOT = False


# ----------------------------
# Domains (CIFAR-10 label ids)
# ----------------------------
DOMAINS = {
    "vehicles_all": [0, 1, 8, 9],
    "animals_all":  [2, 3, 4, 5, 6, 7],
}


# ----------------------------
# Deterministic hashing / seeding
# ----------------------------
def stable_hash(s: str) -> int:
    h = hashlib.md5(s.encode("utf-8")).hexdigest()[:8]
    return int(h, 16)

def stable_hash_tuple(items) -> int:
    return stable_hash("|".join(str(x) for x in items))

def set_seed(seed: int):
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


# ----------------------------
# Backbones
# ----------------------------
def build_backbone(model_name: str, device: torch.device) -> Tuple[nn.Module, int]:
    m = model_name.lower().strip()
    if m == "resnet18":
        w = models.ResNet18_Weights.DEFAULT
        net = models.resnet18(weights=w)
        net.fc = nn.Identity()
        return net.to(device).eval(), 512
    if m == "resnet50":
        w = models.ResNet50_Weights.DEFAULT
        net = models.resnet50(weights=w)
        net.fc = nn.Identity()
        return net.to(device).eval(), 2048
    raise ValueError(f"Unsupported model: {model_name}")


# ----------------------------
# Data transforms
# ----------------------------
def imagenet_like_transform():
    return transforms.Compose([
        transforms.Resize(224),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
                             std=[0.229, 0.224, 0.225]),
    ])


# ----------------------------
# Stratified sampling
# ----------------------------
def stratified_indices(labels_np: np.ndarray, class_list: List[int], total: int, seed: int) -> List[int]:
    """
    Balanced sampling across classes:
      - tries to allocate total//C per class
      - distributes remainder across classes deterministically
      - if a class has insufficient examples, it takes as many as available
    """
    rng = np.random.default_rng(seed)
    classes = list(class_list)
    C = len(classes)

    per = total // C
    rem = total - per * C

    idx_all = []
    # stable class order for deterministic remainder allocation
    classes_sorted = sorted(classes)

    for j, c in enumerate(classes_sorted):
        want = per + (1 if j < rem else 0)
        idx_c = np.where(labels_np == c)[0]
        rng.shuffle(idx_c)
        take = min(want, len(idx_c))
        idx_all.extend(idx_c[:take].tolist())

    rng.shuffle(idx_all)
    return idx_all


# ----------------------------
# Feature extraction
# ----------------------------
@torch.no_grad()
def extract_features(backbone: nn.Module, loader: DataLoader, device: torch.device, limit: int | None = None):
    feats, ys = [], []
    n = 0
    for x, y in loader:
        x = x.to(device)
        h = backbone(x)
        feats.append(h.cpu())
        ys.append(y.cpu())
        n += x.size(0)
        if limit is not None and n >= limit:
            break
    X = torch.cat(feats, dim=0)
    Y = torch.cat(ys, dim=0)
    if limit is not None:
        X = X[:limit]
        Y = Y[:limit]
    return X, Y


# ----------------------------
# Covariance + KL basis
# ----------------------------
def isotropic_shrunk_cov(X: torch.Tensor, shrinkage: float = 0.1) -> torch.Tensor:
    X = X.to(torch.float64)
    X = X - X.mean(dim=0, keepdim=True)
    N, D = X.shape
    if N < 2:
        return torch.eye(D, dtype=torch.float64)
    Sigma = (X.T @ X) / (N - 1)
    a = float(np.clip(shrinkage, 0.0, 1.0))
    tr = torch.trace(Sigma)
    return (1.0 - a) * Sigma + a * (tr / D) * torch.eye(D, dtype=torch.float64)

@torch.no_grad()
def kl_basis_eigh(X_src: torch.Tensor, k: int, shrinkage: float = 0.1) -> torch.Tensor:
    Sigma = isotropic_shrunk_cov(X_src, shrinkage=shrinkage)
    evals, evecs = torch.linalg.eigh(Sigma)
    order = torch.argsort(evals, descending=True)
    U = evecs[:, order]  # [D, D]
    return U[:, :k].contiguous().to(torch.float32)


# ----------------------------
# Random orthonormal basis
# ----------------------------
@torch.no_grad()
def random_orthonormal_basis(D: int, k: int, seed: int) -> torch.Tensor:
    rng = np.random.default_rng(seed)
    A = torch.from_numpy(rng.standard_normal((D, k))).to(torch.float32)
    Q, _ = torch.linalg.qr(A, mode="reduced")
    return Q.contiguous()


# ----------------------------
# Deterministic probe: L2 logistic regression via LBFGS
# ----------------------------
class LinearHead(nn.Module):
    def __init__(self, in_dim: int, n_classes: int):
        super().__init__()
        self.fc = nn.Linear(in_dim, n_classes)

    def forward(self, x):
        return self.fc(x)

def train_logreg_lbfgs(X: torch.Tensor, y: torch.Tensor, in_dim: int, n_classes: int,
                       device: torch.device, l2: float, steps: int = 200) -> nn.Module:
    """
    Deterministic-ish full-batch multinomial logistic regression with L2 penalty.
    Uses LBFGS on full data (no minibatches, no early stopping).
    """
    head = LinearHead(in_dim, n_classes).to(device)
    X = X.to(device)
    y = y.to(device)

    # L2 penalty on weights (not bias)
    def l2_penalty():
        return 0.5 * l2 * (head.fc.weight.pow(2).sum())

    opt = torch.optim.LBFGS(head.parameters(), max_iter=steps, line_search_fn="strong_wolfe")

    def closure():
        opt.zero_grad(set_to_none=True)
        logits = head(X)
        loss = F.cross_entropy(logits, y) + l2_penalty()
        loss.backward()
        return loss

    head.train()
    opt.step(closure)
    head.eval()
    return head

@torch.no_grad()
def accuracy(head: nn.Module, X: torch.Tensor, y: torch.Tensor, device: torch.device) -> float:
    head.eval()
    X = X.to(device)
    y = y.to(device)
    pred = head(X).argmax(dim=1)
    return float((pred == y).float().mean().item())


# ----------------------------
# CSV helper
# ----------------------------
def load_kstar_for_pair(v22_csv: str, model_name: str, src: str, tgt: str, k_field="k_star_median") -> int:
    with open(v22_csv, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for r in reader:
            if (r.get("model", "").strip() == model_name and
                r.get("source", "").strip() == src and
                r.get("target", "").strip() == tgt):
                return int(round(float(r[k_field])))
    raise KeyError(f"Missing row for {model_name} {src}->{tgt} in {v22_csv}")


# ----------------------------
# Main
# ----------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--v22_csv", type=str, default="scaling_results_multibackbone_v22.csv")
    ap.add_argument("--src", type=str, default="vehicles_all")
    ap.add_argument("--tgt", type=str, default="animals_all")
    ap.add_argument("--models", type=str, default="resnet18,resnet50")
    ap.add_argument("--device", type=str, default="auto", choices=["auto", "cpu", "cuda"])

    ap.add_argument("--Ns", type=int, default=2000)
    ap.add_argument("--Nt", type=int, default=100)
    ap.add_argument("--Ntest", type=int, default=2000)

    ap.add_argument("--caps", type=str, default="32,64,99,kstar")
    ap.add_argument("--shrinkage", type=float, default=0.1)

    # Deterministic probe hyperparams
    ap.add_argument("--l2", type=float, default=1e-3, help="L2 strength for logistic regression probe")
    ap.add_argument("--lbfgs_steps", type=int, default=200)

    ap.add_argument("--seeds", type=str, default="20260119,20260218,20260301,20260315,20260329")
    ap.add_argument("--out_dir", type=str, default="outputs_review")
    args = ap.parse_args()

    seed_list = [int(s.strip()) for s in args.seeds.split(",") if s.strip()]
    if len(seed_list) < 1:
        raise ValueError("Provide at least one seed in --seeds")

    if args.device == "auto":
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    else:
        device = torch.device(args.device)

    src = args.src.strip()
    tgt = args.tgt.strip()
    if src not in DOMAINS or tgt not in DOMAINS:
        raise ValueError("src/tgt must be in DOMAINS dict inside script.")

    os.makedirs(args.out_dir, exist_ok=True)
    out_csv_seed = os.path.join(args.out_dir, "cap_sweep_results_per_seed.csv")
    out_csv_mean = os.path.join(args.out_dir, "cap_sweep_results_mean_std.csv")
    out_png = os.path.join(args.out_dir, "cap_sweep_plot_mean_std.png")

    tfm = imagenet_like_transform()
    ds_train = datasets.CIFAR10(root="./data", train=True, download=True, transform=tfm)
    ds_test  = datasets.CIFAR10(root="./data", train=False, download=True, transform=tfm)
    y_train_np = np.array(ds_train.targets, dtype=np.int64)
    y_test_np  = np.array(ds_test.targets, dtype=np.int64)

    # target label remap (within-target)
    tgt_classes_sorted = sorted(set(DOMAINS[tgt]))
    remap = {c: i for i, c in enumerate(tgt_classes_sorted)}
    C = len(tgt_classes_sorted)

    def remap_labels(y_raw: torch.Tensor) -> torch.Tensor:
        return torch.tensor([remap[int(v)] for v in y_raw.tolist()], dtype=torch.long)

    model_list = [m.strip() for m in args.models.split(",") if m.strip()]
    cap_tokens = [t.strip().lower() for t in args.caps.split(",") if t.strip()]

    per_seed_rows = []
    acc = defaultdict(list)       # (model, k_train, method) -> [acc]
    none_acc = defaultdict(list)  # model -> [acc]

    for model_name in model_list:
        backbone, D = build_backbone(model_name, device)

        k_star = load_kstar_for_pair(args.v22_csv, model_name, src, tgt, k_field="k_star_median")
        k_star = max(1, min(k_star, D))

        caps = []
        for token in cap_tokens:
            if token == "kstar":
                caps.append(k_star)
            else:
                caps.append(int(token))
        caps = sorted(set(max(1, min(int(c), D)) for c in caps))

        print("\n" + "=" * 70)
        print(f"{model_name}: D={D} | {src}->{tgt} | k*={k_star} | caps={caps}")
        print(f"Seeds: {seed_list} | Probe: LBFGS L2={args.l2} steps={args.lbfgs_steps}")
        print("=" * 70)

        for seed in seed_list:
            set_seed(seed)

            # Source basis set (stratified)
            seed_src = stable_hash_tuple((seed, model_name, "train", src, args.Ns, "STRAT"))
            idx_src = stratified_indices(y_train_np, DOMAINS[src], args.Ns, seed=int(seed_src))
            loader_src = DataLoader(Subset(ds_train, idx_src), batch_size=128, shuffle=False, num_workers=0)
            Xs, _ = extract_features(backbone, loader_src, device, limit=len(idx_src))

            # Target train (stratified)
            seed_ttr = stable_hash_tuple((seed, model_name, "train", tgt, args.Nt, "STRAT"))
            idx_ttr = stratified_indices(y_train_np, DOMAINS[tgt], args.Nt, seed=int(seed_ttr))
            loader_ttr = DataLoader(Subset(ds_train, idx_ttr), batch_size=128, shuffle=False, num_workers=0)
            Xt_tr, yt_tr_raw = extract_features(backbone, loader_ttr, device, limit=len(idx_ttr))
            yt_tr = remap_labels(yt_tr_raw)

            # Target test (stratified; may truncate due to dataset limits)
            seed_tte = stable_hash_tuple((seed, model_name, "test", tgt, args.Ntest, "STRAT"))
            idx_tte = stratified_indices(y_test_np, DOMAINS[tgt], args.Ntest, seed=int(seed_tte))
            if len(idx_tte) < args.Ntest:
                warnings.warn(f"seed={seed} {model_name} test:{tgt} only has {len(idx_tte)} samples (requested {args.Ntest}).")
            loader_tte = DataLoader(Subset(ds_test, idx_tte), batch_size=128, shuffle=False, num_workers=0)
            Xt_te, yt_te_raw = extract_features(backbone, loader_tte, device, limit=len(idx_tte))
            yt_te = remap_labels(yt_te_raw)

            # NONE baseline (deterministic probe on full D using all Nt)
            head_none = train_logreg_lbfgs(Xt_tr, yt_tr, D, C, device, l2=args.l2, steps=args.lbfgs_steps)
            a_none = accuracy(head_none, Xt_te, yt_te, device)
            none_acc[model_name].append(a_none)

            # KL basis up to k_star (capped by Ns-1)
            max_k_basis = max(1, min(D, int(Xs.shape[0]) - 1))
            k_basis = min(k_star, max_k_basis)
            U_full = kl_basis_eigh(Xs, k=k_basis, shrinkage=args.shrinkage)  # [D, k_basis]

            for k_cap in caps:
                k_train = min(k_cap, k_basis)
                if k_train < 1:
                    continue

                # RANDOM projection
                U_rand = random_orthonormal_basis(D, k_train, seed=stable_hash_tuple((seed, model_name, src, tgt, "rand", k_train)))
                with torch.no_grad():
                    Z_tr_r = (Xt_tr.to(device) @ U_rand.to(device)).cpu()
                    Z_te_r = (Xt_te.to(device) @ U_rand.to(device)).cpu()
                head_r = train_logreg_lbfgs(Z_tr_r, yt_tr, k_train, C, device, l2=args.l2, steps=args.lbfgs_steps)
                a_r = accuracy(head_r, Z_te_r, yt_te, device)

                # SPECTRAL projection
                U_k = U_full[:, :k_train]
                with torch.no_grad():
                    Z_tr = (Xt_tr.to(device) @ U_k.to(device)).cpu()
                    Z_te = (Xt_te.to(device) @ U_k.to(device)).cpu()
                head_s = train_logreg_lbfgs(Z_tr, yt_tr, k_train, C, device, l2=args.l2, steps=args.lbfgs_steps)
                a_s = accuracy(head_s, Z_te, yt_te, device)

                acc[(model_name, k_train, "random")].append(a_r)
                acc[(model_name, k_train, "spectral")].append(a_s)

                per_seed_rows.append({
                    "seed": seed,
                    "model": model_name,
                    "D": D,
                    "source": src,
                    "target": tgt,
                    "Ns_source": int(args.Ns),
                    "Nt_target_train": int(args.Nt),
                    "Ntest_target": int(len(idx_tte)),
                    "k_star_csv": int(k_star),
                    "k_basis_used": int(k_basis),
                    "k_train": int(k_train),
                    "acc_none": float(a_none),
                    "acc_random": float(a_r),
                    "acc_spectral": float(a_s),
                    "gain_spec_minus_rand": float(a_s - a_r),
                    "gain_spec_minus_none": float(a_s - a_none),
                    "l2": float(args.l2),
                    "lbfgs_steps": int(args.lbfgs_steps),
                })

            print(f"  seed={seed} none={a_none:.4f}")

    # Save per-seed CSV
    if per_seed_rows:
        with open(out_csv_seed, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(per_seed_rows[0].keys()))
            w.writeheader()
            for r in per_seed_rows:
                w.writerow(r)
        print("\nSaved per-seed:", os.path.abspath(out_csv_seed))

    # Mean/std rows
    mean_rows = []
    for (model_name, k_train, method), vals in sorted(acc.items(), key=lambda z: (z[0][0], z[0][1], z[0][2])):
        a = np.array(vals, dtype=float)
        mean_rows.append({
            "model": model_name,
            "k_train": int(k_train),
            "method": method,
            "mean_acc": float(a.mean()),
            "std_acc": float(a.std(ddof=1)) if len(a) > 1 else 0.0,
            "n_seeds": int(len(a)),
            "Ns": int(args.Ns),
            "Nt": int(args.Nt),
            "Ntest": int(args.Ntest),
            "l2": float(args.l2),
            "lbfgs_steps": int(args.lbfgs_steps),
        })

    for model_name, vals in none_acc.items():
        a = np.array(vals, dtype=float)
        mean_rows.append({
            "model": model_name,
            "k_train": "NA",
            "method": "none",
            "mean_acc": float(a.mean()),
            "std_acc": float(a.std(ddof=1)) if len(a) > 1 else 0.0,
            "n_seeds": int(len(a)),
            "Ns": int(args.Ns),
            "Nt": int(args.Nt),
            "Ntest": int(args.Ntest),
            "l2": float(args.l2),
            "lbfgs_steps": int(args.lbfgs_steps),
        })

    if mean_rows:
        with open(out_csv_mean, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(mean_rows[0].keys()))
            w.writeheader()
            for r in mean_rows:
                w.writerow(r)
        print("Saved mean/std:", os.path.abspath(out_csv_mean))

    # Plot mean ± std
    if PLOT and mean_rows:
        plt.figure(figsize=(10, 6))

        for model_name in sorted(set(r["model"] for r in mean_rows)):
            rows_m = [r for r in mean_rows if r["model"] == model_name]

            none_row = [r for r in rows_m if r["method"] == "none"]
            mu_none = none_row[0]["mean_acc"] if none_row else None
            sd_none = none_row[0]["std_acc"] if none_row else None

            for method, marker, ls in [("spectral", "o", "-"), ("random", "x", "--")]:
                rows_k = [r for r in rows_m if r["method"] == method and r["k_train"] != "NA"]
                rows_k = sorted(rows_k, key=lambda z: int(z["k_train"]))
                ks = np.array([int(r["k_train"]) for r in rows_k], dtype=int)
                mu = np.array([r["mean_acc"] for r in rows_k], dtype=float)
                sd = np.array([r["std_acc"] for r in rows_k], dtype=float)

                plt.plot(ks, mu, marker=marker, linestyle=ls, label=f"{model_name} {method}")
                plt.fill_between(ks, mu - sd, mu + sd, alpha=0.2)

            # none horizontal line + band across ks range
            rows_any = [r for r in rows_m if r["method"] == "spectral" and r["k_train"] != "NA"]
            if mu_none is not None and rows_any:
                ks_any = sorted(int(r["k_train"]) for r in rows_any)
                xmin, xmax = min(ks_any), max(ks_any)
                plt.hlines(mu_none, xmin=xmin, xmax=xmax, linestyles=":", label=f"{model_name} none")
                if sd_none is not None and sd_none > 0:
                    plt.fill_between([xmin, xmax], [mu_none - sd_none, mu_none - sd_none],
                                     [mu_none + sd_none, mu_none + sd_none], alpha=0.12)

        plt.xlabel("k_train (projection rank used for training)")
        plt.ylabel("Target test accuracy (mean ± 1 std over seeds)")
        plt.title(f"Cap sweep (stratified + deterministic probe): {args.src} → {args.tgt} (Ns={args.Ns}, Nt={args.Nt})")
        plt.grid(True, alpha=0.3)
        plt.legend()
        plt.savefig(out_png, dpi=160, bbox_inches="tight")
        plt.close()
        print("Saved plot:", os.path.abspath(out_png))

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
